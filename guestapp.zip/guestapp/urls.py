from django.urls import path
from . import views

urlpatterns=[

path('',views.index,name='index'),
path('login',views.login,name='login'),
path('tlogin',views.tlogin,name='tlogin'),
path('owner',views.owner,name='owner'),
path('showreg',views.showreg,name='showreg'),
path('findrec',views.findrec,name='findrec'),
path('findrec1',views.findrec1,name='findrec1'),
path('editrec',views.editrec,name='editrec'),
path('deleterec',views.deleterec,name='deleterec')

]
